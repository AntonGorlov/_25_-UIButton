//
//  ViewController.m
//  UIButton (Lesson 25)
//
//  Created by Anton Gorlov on 15.02.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIButton* button = [UIButton buttonWithType:UIButtonTypeCustom]; //соз кнопку (свою)
    button.frame = CGRectMake(100, 200, 150, 60); // создаем размер кнопки
    button.backgroundColor = [UIColor lightGrayColor]; // выставляем фон кнопки
    /*
    [button setTitleColor:[UIColor magentaColor] forState:UIControlStateNormal]; //выставляем цвет кнопки (надписи) при нормальном состоянии
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateHighlighted]; //выставляем цвет кнопки (надписи) при нажатии
    
    
    [button setTitle:@"My first Button" forState:UIControlStateNormal]; //подписываем кнопку и выставляем состояние кнопки.
    [button setTitle:@"My first Button Preesed" forState:UIControlStateHighlighted]; //подписываем кнопку и выставляем состояние кнопки.(кнопка нажата)
    */
   // [self.view addSubview:button];//добавляем на наш вью
    
   //для того,чтобы поменять шрифт(font) на кнопке нужно создать NSAttributedString и поставить его туда.
    
/*
    NSDictionary* attributes = [NSDictionary dictionaryWithObjectsAndKeys:
                                 [UIFont systemFontOfSize:25] , NSFontAttributeName,
                                 [UIColor orangeColor] , NSForegroundColorAttributeName, nil];
 
// или другой метод создания ( NSDictionary) ключей!!!
    
    NSDictionary* attributes2 =   @{NSFontAttributeName: [UIFont systemFontOfSize:25],  NSForegroundColorAttributeName: [UIColor orangeColor]};



//создаем NSAttributedString
    
    NSAttributedString* title = [[NSAttributedString alloc] initWithString:@"Button" attributes:attributes];//это строка,которая будет содержать какие-то атрибуты
    [button setAttributedTitle:title forState:UIControlStateNormal]; // выставляем атрибуты для кнопки
    
    //для нажатого состояния
    
    NSDictionary* attributes2 = [NSDictionary dictionaryWithObjectsAndKeys:
                                [UIFont systemFontOfSize:10] , NSFontAttributeName,
                                [UIColor blueColor] , NSForegroundColorAttributeName, nil];
    
    NSAttributedString* title2 = [[NSAttributedString alloc] initWithString:@"Button Pressed" attributes:attributes2];
    [button setAttributedTitle:title2 forState:UIControlStateHighlighted];

*/
    
    [button setTitle:@"Button" forState:UIControlStateNormal];
    [button setTitle:@"Button Pressed" forState:UIControlStateHighlighted];
    [button setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [button setTitleColor:[UIColor greenColor] forState:UIControlStateHighlighted];

     //UIEdgeInsets insets = UIEdgeInsetsMake(100, 100, 0, 0); //UIEdgeInsets - отступы внутри ,а UIOffset - снаружи
    //button.titleEdgeInsets = insets; //устанавливаем
    
    //события,которые вызывает кнопка
    
    [button addTarget:self action:@selector(actionTest:event:) forControlEvents:UIControlEventTouchUpInside];
    //Target-ом наз тот обьект,которому будет отправлено сообщение (Первый метод для кнопки(Target) по событию TouchUpInside)
    
    [button addTarget:self action:@selector(actionTestOutside:) forControlEvents:UIControlEventTouchUpOutside];
    //(Второй метод для кнопки (Target) по событию TouchUpOutside)




}

//названия для кнопок (Алексей называет так методы - "Actions")
#pragma mark - Actions

- (void) actionTest:(UIButton*) butt event:(UIEvent*) event {
    
    NSLog(@"Button Pressed Inside!");//это для первой кнопки созданной в коде
    
}

- (void) actionTestOutside:(UIButton*) button {
    
    NSLog(@"Button Pressed Outside!");//это для первой кнопки созданной в коде
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)actionTest2:(UIButton *)sender { // для кнопки созданной в storyBoard
    NSLog(@"actionTest2 tag = %ld",sender.tag);
    self.indicatorLabel.text = [NSString stringWithFormat:@"%ld",sender.tag];

   
}

- (IBAction)actionTest2TouchDown:(UIButton*)sender {
    
     NSLog(@"actionTest2TouchDown");

}

@end
